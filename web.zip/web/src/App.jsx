import { useState, useCallback } from 'react'

function App() {
  const [selectedFile, setSelectedFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [dragging, setDragging] = useState(false)

  const handleFileSelect = useCallback((file) => {
    if (!file) return
    
    const validTypes = ['image/jpeg', 'image/png', 'image/webp']
    if (!validTypes.includes(file.type)) {
      setError('请上传 JPEG、PNG 或 WebP 格式的图片')
      return
    }
    
    if (file.size > 5 * 1024 * 1024) {
      setError('文件大小不能超过 5MB')
      return
    }
    
    setSelectedFile(file)
    setPreview(URL.createObjectURL(file))
    setResult(null)
    setError(null)
  }, [])

  const handleDrop = useCallback((e) => {
    e.preventDefault()
    setDragging(false)
    const file = e.dataTransfer.files[0]
    handleFileSelect(file)
  }, [handleFileSelect])

  const handleDragOver = useCallback((e) => {
    e.preventDefault()
    setDragging(true)
  }, [])

  const handleDragLeave = useCallback(() => {
    setDragging(false)
  }, [])

  const handleInputChange = useCallback((e) => {
    const file = e.target.files[0]
    handleFileSelect(file)
  }, [handleFileSelect])

  const analyzeImage = async () => {
    if (!selectedFile) return
    
    setLoading(true)
    setError(null)
    
    try {
      const formData = new FormData()
      formData.append('image', selectedFile)
      
      const response = await fetch('/api/analyze', {
        method: 'POST',
        body: formData,
      })
      
      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.detail || '分析失败')
      }
      
      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(err.message || '网络错误，请重试')
    } finally {
      setLoading(false)
    }
  }

  // 计算综合可靠性评估
  const calculateReliability = (analysis) => {
    if (!analysis) return { level: 'unknown', label: '无法判断', summary: '' }
    
    let totalScore = 0
    let factorCount = 0
    const factors = []
    
    // 可信度模块的各项评分
    const credibilityItems = analysis.credibility?.items || []
    credibilityItems.forEach(item => {
      const conf = item.confidence
      let score = conf === 'high' ? 3 : conf === 'medium' ? 2 : 1
      totalScore += score
      factorCount++
    })
    
    // 人物检测评分
    const person = analysis.person || {}
    if (person.detected) {
      if (person.confidence === 'high') totalScore += 3
      else if (person.confidence === 'medium') totalScore += 2
      else totalScore += 1
      factorCount++
    }
    
    // 房间分析评分
    const room = analysis.room_analysis || {}
    if (room.confidence === 'high') totalScore += 3
    else if (room.confidence === 'medium') totalScore += 2
    else totalScore += 1
    factorCount++
    
    const avgScore = factorCount > 0 ? totalScore / factorCount : 0
    
    let level, label, summary
    if (avgScore >= 2.5) {
      level = 'high'
      label = '可信度较高'
      summary = '综合分析显示，该照片的真实性指标较好，图片元数据完整，各项分析一致性较高。'
    } else if (avgScore >= 1.8) {
      level = 'medium'
      label = '可信度中等'
      summary = '综合分析显示，该照片的部分指标正常，但存在一些不确定因素，建议结合其他信息综合判断。'
    } else if (avgScore >= 1) {
      level = 'low'
      label = '可信度较低'
      summary = '综合分析显示，该照片的多项指标存在疑问，证据不足或存在异常，请谨慎对待。'
    } else {
      level = 'unknown'
      label = '无法判断'
      summary = '分析信息不足，无法给出可靠性评估。'
    }
    
    return { level, label, summary }
  }

  // 收集场景描述
  const getSceneDescription = (analysis) => {
    if (!analysis) return ''
    
    const descriptions = []
    
    // 从 lifestyle items 获取场景信息
    const lifestyleItems = analysis.lifestyle?.items || []
    lifestyleItems.forEach(item => {
      if (item.claim && item.claim.includes('场景判断')) {
        descriptions.push(item.claim)
      }
    })
    
    // 从 room_analysis 获取
    const room = analysis.room_analysis || {}
    if (room.clues) {
      const clues = room.clues
      if (clues.space_layout && !clues.space_layout.includes('未见')) {
        descriptions.push(`空间布局：${clues.space_layout}`)
      }
      if (clues.decoration && !clues.decoration.includes('未见')) {
        descriptions.push(`装饰风格：${clues.decoration}`)
      }
    }
    
    return descriptions.length > 0 ? descriptions.join('；') : '未能识别明确的场景特征'
  }

  // 收集所有论据
  const collectEvidences = (analysis) => {
    if (!analysis) return []
    
    const evidences = []
    
    // 房间分析论据
    const room = analysis.room_analysis || {}
    if (room.evidence && room.evidence.length > 0) {
      evidences.push({
        category: '环境线索',
        items: room.evidence
      })
    }
    
    // 房间线索详情
    if (room.clues) {
      const clueItems = []
      Object.entries(room.clues).forEach(([key, value]) => {
        if (value && !value.includes('未见相关')) {
          const labels = {
            tableware: '餐具线索',
            seating: '座位线索',
            personal_items: '个人物品',
            decoration: '装饰风格',
            space_layout: '空间布局'
          }
          clueItems.push(`${labels[key] || key}：${value}`)
        }
      })
      if (clueItems.length > 0) {
        evidences.push({
          category: '环境细节线索',
          items: clueItems
        })
      }
    }
    
    // 人物分析论据
    const person = analysis.person || {}
    if (person.evidence_list && person.evidence_list.length > 0) {
      evidences.push({
        category: '人物特征依据',
        items: person.evidence_list
      })
    }
    
    // 性别判断依据
    if (person.gender_evidence) {
      const genderItems = []
      if (person.gender_evidence.appearance && !person.gender_evidence.appearance.includes('N/A')) {
        genderItems.push(person.gender_evidence.appearance)
      }
      if (person.gender_evidence.environment && !person.gender_evidence.environment.includes('N/A')) {
        genderItems.push(person.gender_evidence.environment)
      }
      if (genderItems.length > 0) {
        evidences.push({
          category: '性别判断依据',
          items: genderItems
        })
      }
    }
    
    // 可信度分析论据
    const credItems = analysis.credibility?.items || []
    const credEvidences = []
    credItems.forEach(item => {
      if (item.evidence && item.evidence.length > 0) {
        credEvidences.push(...item.evidence)
      }
    })
    if (credEvidences.length > 0) {
      evidences.push({
        category: '可信度分析依据',
        items: credEvidences
      })
    }
    
    return evidences
  }

  const analysis = result?.analysis
  const reliability = calculateReliability(analysis)

  return (
    <div className="app">
      <header className="header">
        <h1>网恋安全卫士</h1>
        <p>您最忠心的恋爱侦探</p>
      </header>

      <section className="upload-section">
        <div 
          className={`upload-area ${dragging ? 'dragging' : ''}`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={() => document.getElementById('fileInput').click()}
        >
          <div className="upload-icon">📷</div>
          <div className="upload-text">点击或拖拽上传照片</div>
          <div className="upload-hint">支持 JPEG、PNG、WebP 格式，最大 5MB</div>
          <input 
            type="file" 
            id="fileInput"
            accept="image/jpeg,image/png,image/webp"
            style={{ display: 'none' }}
            onChange={handleInputChange}
          />
        </div>
        
        {preview && (
          <div className="preview-container">
            <img src={preview} alt="预览" className="preview-image" />
            <br />
            <button 
              className="analyze-btn" 
              onClick={analyzeImage}
              disabled={loading}
            >
              {loading ? '分析中...' : '开始分析'}
            </button>
          </div>
        )}
      </section>

      {error && <div className="error-message">{error}</div>}

      {loading && (
        <div className="loading">
          <div className="loading-spinner"></div>
          <p>正在分析照片，请稍候...</p>
        </div>
      )}

      {result && analysis && (
        <div className="results-section">
          {/* 可靠性结论卡片 */}
          <div className="result-card reliability-card">
            <h2><span className="card-icon">🎯</span> 可靠性综合评估</h2>
            <div className="reliability-conclusion">
              <div className={`reliability-badge badge-${reliability.level}`}>
                {reliability.label}
              </div>
              <p className="reliability-summary">{reliability.summary}</p>
            </div>
            
            <div className="confidence-factors">
              {analysis.credibility?.items?.map((item, idx) => (
                <div key={idx} className="factor-item">
                  <span className="factor-icon">
                    {item.confidence === 'high' ? '✅' : item.confidence === 'medium' ? '⚠️' : '❓'}
                  </span>
                  <div className="factor-content">
                    <div className="factor-claim">
                      {item.claim}
                      <span className={`confidence-tag conf-${item.confidence}`}>
                        {item.confidence === 'high' ? '高置信' : item.confidence === 'medium' ? '中置信' : '低置信'}
                      </span>
                    </div>
                    <div className="factor-evidence">
                      {item.evidence?.join('；')}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 房间分析卡片 */}
          <div className="result-card room-card">
            <h2><span className="card-icon">🏠</span> 房间与人物分析</h2>
            
            <div className="room-overview">
              <div className="room-stat">
                <div className="stat-label">推断人数</div>
                <div className="stat-value">{analysis.room_analysis?.inferred_people_count || '无法判断'}</div>
              </div>
              <div className="room-stat">
                <div className="stat-label">性别判断</div>
                <div className="stat-value">{analysis.person?.gender || '无法判断'}</div>
              </div>
              <div className="room-stat">
                <div className="stat-label">关系推断</div>
                <div className="stat-value">{analysis.room_analysis?.relationship_hint || '无法判断'}</div>
              </div>
              <div className="room-stat">
                <div className="stat-label">检测人数</div>
                <div className="stat-value">{analysis.person?.count || 0} 人</div>
              </div>
            </div>

            <div className="scene-description">
              <div className="scene-title">📍 场景信息描述</div>
              <p className="scene-text">{getSceneDescription(analysis)}</p>
            </div>

            {/* 人物体征 */}
            {analysis.person?.detected && (
              <div className="room-overview" style={{ marginTop: '16px' }}>
                <div className="room-stat">
                  <div className="stat-label">身高判断</div>
                  <div className="stat-value">{analysis.person.height}</div>
                </div>
                <div className="room-stat">
                  <div className="stat-label">体型判断</div>
                  <div className="stat-value">{analysis.person.body_type}</div>
                </div>
                <div className="room-stat">
                  <div className="stat-label">姿态判断</div>
                  <div className="stat-value">{analysis.person.posture}</div>
                </div>
              </div>
            )}

            {analysis.room_analysis?.limitations && (
              <div className="limitations">
                <div className="limitations-title">⚠️ 分析局限性</div>
                <ul>
                  {analysis.room_analysis.limitations.map((lim, idx) => (
                    <li key={idx}>{lim}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* 论据列表卡片 */}
          <div className="result-card evidence-card">
            <h2><span className="card-icon">📋</span> 分析论据详情</h2>
            
            <div className="evidence-list">
              {collectEvidences(analysis).map((group, idx) => (
                <div key={idx} className="evidence-item">
                  <div className="evidence-category">{group.category}</div>
                  <div className="evidence-content">
                    <ul>
                      {group.items.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>

            {/* 环境线索网格 */}
            {analysis.room_analysis?.clues && Object.keys(analysis.room_analysis.clues).length > 0 && (
              <>
                <h3 style={{ marginTop: '24px', marginBottom: '12px', fontSize: '1rem', color: '#555' }}>
                  环境线索明细
                </h3>
                <div className="clues-grid">
                  {Object.entries(analysis.room_analysis.clues).map(([key, value]) => (
                    <div key={key} className="clue-item">
                      <div className="clue-label">
                        {{
                          tableware: '餐具',
                          seating: '座位',
                          personal_items: '个人物品',
                          decoration: '装饰',
                          space_layout: '空间布局'
                        }[key] || key}
                      </div>
                      <div className="clue-value">{value}</div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default App
